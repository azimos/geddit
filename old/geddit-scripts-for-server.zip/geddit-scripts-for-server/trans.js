
$(document).ready(function(){

	$("input").keypress(function(event) {
    if (event.which == 13) {
        event.preventDefault();
        	$('#reload-j').css('display', 'block');

$("#reload-j").html("<img src='http://test.bitconnect.ca/loading-icon.gif' alt='description' />");
	var user_text = $('#txt_name').val();
	var url_api = "http://test.bitconnect.ca/cgi-bin/test_modified.py?search_title=" + user_text;
	$.get( url_api ,function( data ) {
					$('#area').css('display', 'block');

		$('#all-cont').css('display', 'none');

    $("#area").html(data);

});    }
});
$('#re-text').css('display', 'none');

$("#input-loading").click(function () {
	$('#reload-j').css('display', 'block');

	$("#reload-j").html("<img src='http://test.bitconnect.ca/loading-icon.gif' alt='description' />");
	var user_text = $('#txt_name').val();
	var url_api = "http://test.bitconnect.ca/cgi-bin/test_modified.py?search_title=" + user_text;
	$.get( url_api ,function( data ) {
					$('#area').css('display', 'block');
				
		$('#all-cont').css('display', 'none');

    $("#area").html(data);
if ($("#area").text().length > 0) {




localStorage.setItem(user_text, data);

   }                      
});

});

$("#backbtn").click(function () {
	$('#area').css('display', 'none');
	$('#all-cont').css('display', 'block');	
		$('#reload-j').css('display', 'none');
			$('#all-cont-alt-ex1').css('display', 'none');	
			$('#all-cont-alt-ex2').css('display', 'none');
						$('#all-cont-alt-ex3').css('display', 'none');




});
	


$('#all-cont-alt-ex1').css('display', 'none');
$('#all-cont-alt-ex2').css('display', 'none');
$('#all-cont-alt-ex3').css('display', 'none');

$("#example-topics-1").click(function () {
		$('#all-cont').css('display', 'none');

        $('#all-cont-alt-ex1').css('display', 'block');
});
$("#example-topics-2").click(function () {
		$('#all-cont').css('display', 'none');
        $('#all-cont-alt-ex2').css('display', 'block');

});
$("#example-topics-3").click(function () {
		$('#all-cont').css('display', 'none');
        $('#all-cont-alt-ex3').css('display', 'block');

});

});


