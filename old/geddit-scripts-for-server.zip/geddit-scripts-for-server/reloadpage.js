$(document).ready(function(){

$( "#backbtn" ).on( "click", function() {
	$('#area').css('display', 'none');
	$('#all-cont').css('display', 'block');	
		$('#reload-j').css('display', 'none');
			$('#all-cont-alt-ex1').css('display', 'none');	
			$('#all-cont-alt-ex2').css('display', 'none');
			$('#all-cont-alt-ex3').css('display', 'none');




});


    
});