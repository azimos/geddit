
$(document).ready(function(){
$('#error-msg').css('display', 'none');
   
document.addEventListener("backbutton", function(e){
    if($.mobile.activePage.is('#homepage')){
        /* 
         Event preventDefault/stopPropagation not required as adding backbutton
          listener itself override the default behaviour. Refer below PhoneGap link.
        */
        //e.preventDefault();
        navigator.app.exitApp();
    }
    else {
    document.getElementById("display-nav").style.display = "none";
            document.getElementById("text-test").style.display = "none";

            document.getElementById("all-cont-alt-ex1").style.display = "none";
            document.getElementById("all-cont-alt-ex2").style.display = "none";
            document.getElementById("all-cont-alt-ex3").style.display = "none";
                        document.getElementById("all-cont-alt-ex3").style.display = "none";

                        document.getElementById("all-cont").style.display = "block";
                                    document.getElementById("area").style.display = "none";
                                                document.getElementById("reload-j").style.display = "none";

    }
    return false;
});
    //form sumbit enter key event

	$("input").keypress(function(event) {
    if (event.which == 13) {
        event.preventDefault();
    var user_text = $('#txt_name').val();

   if ( $.trim( $('#txt_name').val() ) == '' )
{
     $("#error-msg").html(user_text);

            $('#error-msg').css('display', 'block');


    } else {

           $('#reload-j').css('display', 'block');
    
    $("#reload-j").html("<img src='http://test.bitconnect.ca/loading-icon.gif' alt='description' />");

        var url_api = "http://test.bitconnect.ca/cgi-bin/test_modified.py?search_title=" + user_text;
    $.get( url_api ,function( data ) {
                    $('#area').css('display', 'block');
                
        $('#all-cont').css('display', 'none');

    $("#area").html(data);
if ($("#area").text().length > 45) {




localStorage.setItem(user_text, data);

   }                      
}); 
    }
}
});

$('#re-text').css('display', 'none');
//form submit click event
$("#input-loading").click(function () {

	var user_text = $('#txt_name').val();

   if ( $.trim( $('#txt_name').val() ) == '' )
{
     $("#error-msg").html(user_text);

            $('#error-msg').css('display', 'block');


    } else {

           $('#reload-j').css('display', 'block');
    
    $("#reload-j").html("<img src='http://test.bitconnect.ca/loading-icon.gif' alt='description' />");

        var url_api = "http://test.bitconnect.ca/cgi-bin/test_modified.py?search_title=" + user_text;
    $.get( url_api ,function( data ) {
                    $('#area').css('display', 'block');
                
        $('#all-cont').css('display', 'none');

    $("#area").html(data);
if ($("#area").text().length > 45) {




localStorage.setItem(user_text, data);

   }                      
}); 
    
}
});

$("#backbtn").click(function () {
	$('#area').css('display', 'none');
	$('#all-cont').css('display', 'block');	
		$('#reload-j').css('display', 'none');
			$('#all-cont-alt-ex1').css('display', 'none');	
			$('#all-cont-alt-ex2').css('display', 'none');
						$('#all-cont-alt-ex3').css('display', 'none');




});
	


$('#all-cont-alt-ex1').css('display', 'none');
$('#all-cont-alt-ex2').css('display', 'none');
$('#all-cont-alt-ex3').css('display', 'none');

$("#example-topics-1").click(function () {
		$('#all-cont').css('display', 'none');

        $('#all-cont-alt-ex1').css('display', 'block');
});
$("#example-topics-2").click(function () {
		$('#all-cont').css('display', 'none');
        $('#all-cont-alt-ex2').css('display', 'block');

});
$("#example-topics-3").click(function () {
		$('#all-cont').css('display', 'none');
        $('#all-cont-alt-ex3').css('display', 'block');

});

});


