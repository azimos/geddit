
$(document).ready(function(){

$('h5').click(function () {
     var bla = $(this).val();
    $('#reload-j').css('display', 'block');

    $("#reload-j").html("<img src='http://test.bitconnect.ca/loading-icon.gif' alt='description' />");
   
    var url_api = "http://test.bitconnect.ca/cgi-bin/test_modified.py?search_title=" + bla;
    $.get( url_api ,function( data ) {
                    $('#area').css('display', 'block');
                
        $('#all-cont').css('display', 'none');

    $("#area").html(data);
if ($("#area").text().length > 25) {




localStorage.setItem(user_text, data);

   }                      
});

});
});
